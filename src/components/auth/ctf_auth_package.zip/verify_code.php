<?php
require 'db_connect.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$email = isset($input['email']) ? trim($input['email']) : '';
$code = isset($input['code']) ? trim($input['code']) : '';

if (!$email || !$code) {
    echo json_encode(['success'=>false,'message'=>'Missing email or code']);
    exit;
}

$stmt = $conn->prepare('SELECT id, verification_code, is_verified, expires_at FROM email_verifications WHERE email = ? ORDER BY created_at DESC LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(['success'=>false,'message'=>'No verification request found']);
    exit;
}

if ($row['is_verified']) {
    echo json_encode(['success'=>false,'message'=>'Already verified']);
    exit;
}

if (strtotime($row['expires_at']) < time()) {
    echo json_encode(['success'=>false,'message'=>'Code expired']);
    exit;
}

if ($row['verification_code'] !== $code) {
    echo json_encode(['success'=>false,'message'=>'Invalid code']);
    exit;
}

// mark as verified
$upd = $conn->prepare('UPDATE email_verifications SET is_verified = 1 WHERE id = ?');
$upd->bind_param('i', $row['id']);
$upd->execute();
$upd->close();

echo json_encode(['success'=>true,'message'=>'Code verified']);
?>