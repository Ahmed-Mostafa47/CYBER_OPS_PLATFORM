<?php
require 'db_connect.php';
header('Content-Type: application/json');

// Try to use PHPMailer if available
$usePHPMailer = file_exists(__DIR__ . '/vendor/autoload.php');
if ($usePHPMailer) {
    require __DIR__ . '/vendor/autoload.php';
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
}

// Read JSON input
$input = json_decode(file_get_contents('php://input'), true);
$username = isset($input['username']) ? trim($input['username']) : '';
$email = isset($input['email']) ? trim($input['email']) : '';

if (!$username || !$email) {
    echo json_encode(['success' => false, 'message' => 'Missing username or email']);
    exit;
}

// generate 6-digit numeric code
$code = str_pad(strval(rand(0, 999999)), 6, '0', STR_PAD_LEFT);

// delete previous verifications for the email
$stmt = $conn->prepare('DELETE FROM email_verifications WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->close();

// insert new verification
$stmt = $conn->prepare('INSERT INTO email_verifications (email, username, verification_code, is_verified, expires_at) VALUES (?, ?, ?, 0, DATE_ADD(NOW(), INTERVAL 10 MINUTE))');
$stmt->bind_param('sss', $email, $username, $code);
if (!$stmt->execute()) {
    echo json_encode(['success'=>false,'message'=>'DB insert failed']);
    exit;
}
$stmt->close();

// send email
$subject = 'CTF Platform - Verification Code';
$bodyText = "Hello $username,\n\nYour verification code is: $code\nIt expires in 10 minutes.\n\nIf you didn't request this, ignore.\n";

if ($usePHPMailer) {
    try {
        $mail = new PHPMailer(true);
        // SMTP settings - replace placeholders
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'YOUR_EMAIL@gmail.com'; // <-- change
        $mail->Password = 'YOUR_APP_PASSWORD';    // <-- change (App Password)
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('YOUR_EMAIL@gmail.com', 'CTF Platform');
        $mail->addAddress($email, $username);
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body = $bodyText;

        $mail->send();
        echo json_encode(['success'=>true, 'message'=>'Code sent via SMTP']);
    } catch (Exception $e) {
        echo json_encode(['success'=>false, 'message'=>'Mailer error: ' . $mail->ErrorInfo]);
    }
} else {
    // fallback to PHP mail()
    $headers = 'From: no-reply@ctfplatform.local' . "\r\n" .
               'Reply-To: no-reply@ctfplatform.local' . "\r\n" .
               'X-Mailer: PHP/' . phpversion();
    $sent = mail($email, $subject, $bodyText, $headers);
    if ($sent) {
        echo json_encode(['success'=>true, 'message'=>'Code sent via mail()']);
    } else {
        echo json_encode(['success'=>false, 'message'=>'mail() failed. Install PHPMailer or configure sendmail.']);
    }
}
?>